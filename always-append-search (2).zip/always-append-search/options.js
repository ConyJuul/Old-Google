const input = document.getElementById("suffix");
const status = document.getElementById("status");

chrome.storage.sync.get({ suffix: "" }).then((r) => {
  input.value = r.suffix;
});

document.getElementById("save").addEventListener("click", async () => {
  await chrome.storage.sync.set({ suffix: input.value });
  status.textContent = "Saved!";
  setTimeout(() => (status.textContent = ""), 1200);
});
