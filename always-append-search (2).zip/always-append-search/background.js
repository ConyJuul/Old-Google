// Maps each supported search engine to the URL pattern that identifies a
// results page, and the name of the query-string parameter holding the
// search terms.
const ENGINES = [
  { host: "www.google.com", path: "/search", param: "q" },
  { host: "www.bing.com", path: "/search", param: "q" },
  { host: "duckduckgo.com", path: "/", param: "q" },
  { host: "search.brave.com", path: "/search", param: "q" },
  { host: "www.startpage.com", path: "/sp/search", param: "query" },
];

const DEFAULT_SUFFIX = ""; // optional keyword to append; leave blank to only apply udm=14

// A marker we stash in the URL so we never re-append the suffix to a URL
// we already rewrote (which would otherwise loop forever).
const MARKER_PARAM = "_aas"; // "always append search"

function getSuffix() {
  return chrome.storage.sync.get({ suffix: DEFAULT_SUFFIX }).then((r) => r.suffix);
}

function matchEngine(url) {
  return ENGINES.find((e) => url.hostname === e.host && url.pathname === e.path);
}

async function maybeRewrite(details) {
  console.log("[AAS] onBeforeNavigate fired:", details.url, "frameId:", details.frameId);

  // Ignore sub-frames (iframes, ads, etc.) - only rewrite the main page.
  if (details.frameId !== 0) {
    console.log("[AAS] skipped: not main frame");
    return;
  }

  let url;
  try {
    url = new URL(details.url);
  } catch {
    console.log("[AAS] skipped: URL failed to parse");
    return;
  }

  const engine = matchEngine(url);
  if (!engine) {
    console.log("[AAS] skipped: no matching engine for host", url.hostname, "path", url.pathname);
    return;
  }

  const q = url.searchParams.get(engine.param);
  if (!q) {
    console.log("[AAS] skipped: no query param found");
    return;
  }

  // Already processed by us - don't append twice.
  if (url.searchParams.has(MARKER_PARAM)) {
    console.log("[AAS] skipped: already has marker param");
    return;
  }

  const suffix = (await getSuffix()).trim();
  let changed = false;

  // Optional keyword suffix (off by default now - see DEFAULT_SUFFIX above).
  if (suffix) {
    const alreadyHasSuffix = q.trim().endsWith(suffix);
    if (!alreadyHasSuffix) {
      url.searchParams.set(engine.param, `${q} ${suffix}`);
      changed = true;
    }
  }

  // Google-specific: udm=14 forces the plain "Web" results tab, which is the
  // reliable way to suppress the AI Overview panel without touching the
  // query text itself (so it doesn't filter out legitimate results).
  if (url.hostname === "www.google.com" && url.searchParams.get("udm") !== "14") {
    url.searchParams.set("udm", "14");
    changed = true;
  }

  if (!changed) {
    console.log("[AAS] skipped: nothing to change");
    return;
  }

  url.searchParams.set(MARKER_PARAM, "1");

  console.log("[AAS] redirecting tab", details.tabId, "to", url.toString());
  chrome.tabs.update(details.tabId, { url: url.toString() }).catch((err) => {
    console.log("[AAS] tabs.update failed:", err);
  });
}

chrome.webNavigation.onBeforeNavigate.addListener(maybeRewrite);
